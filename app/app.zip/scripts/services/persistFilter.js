'use strict';

angular.module('halamanHeritageApp')
  .service('persistFilter', function persistFilter() {
    return { init: '' };
  });
